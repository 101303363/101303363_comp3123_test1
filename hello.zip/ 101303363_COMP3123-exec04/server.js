const { query } = require("express")
const express =require("express")
const app =express()

const SERVER_PORT =8088
// GET request
app.get("/hello",(req,res)=>{
    res.send("<h1>Hello Express JS</h1>")
})
// GET request Querystring to send values
// app.get("/user",(req,res)=>{
//     var information={
//         firstname:"Onur",
//         lastname:"Korkmaz"
//     }
//     res.send(information)
// })

// GET request Querystring to send values
app.get("/user",(req,res)=>{
    var queryParameter =req.query;
    res.json(queryParameter)
})



//  POST Use path parameter to send values

// http://localhost:8088/firstname/lastname
app.post("/user/:pfirstname/:plastname",(req,res)=>{
    const firstname=req.params.pfirstname
    const lastname=req.params.plastname
    res.send({
        firstname,
        lastname
    })
})

app.listen(SERVER_PORT,()=>{
    console.log("Server running at http://localhost:8088")
})


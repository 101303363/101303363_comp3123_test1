const my_array =['Pizza',10, true, 25, false, 'Wings']

const filter_the_value=my_array.filter(word=>word.length>0);
const to_lower_case =filter_the_value.map(element=>{
     return element.toLowerCase()
})
console.log(to_lower_case)



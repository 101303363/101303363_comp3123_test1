

const fs = require('fs');
const path = require('path');

if (fs.existsSync("Logs")){

    fs.readdirSync("Logs")
        .forEach(file => {
        fs.unlinkSync(path.join("Logs", file))
        console.log(`Deleted files ..... ${file}`)
    })
    fs.rmdirSync("Logs")
}

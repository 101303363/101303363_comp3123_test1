const fs = require('fs');
const path = require('path');

if (!fs.existsSync("Logs")) {
    
    fs.mkdirSync("Logs")

    for(i = 0; i < 10; i++) {
        fs.writeFileSync(`Logs/log${i}.txt`, "T177,Korkmaz,Onur,FullStack I")
    }
}


